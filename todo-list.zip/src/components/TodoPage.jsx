import React, { Component } from 'react';
import { ItemsList } from "./ItemsList";
import { AddTaskModal } from "./AddTaskModal";

class TodoPage extends Component {
  constructor(props) {
    super(props);

    this.state = {
      tasks: [],
      isAddTaskModalOpened: false
    }
  }

  async componentDidMount() {
    const response = await fetch( 'http://localhost:4000/tasks');
    const data = await response.json();
    this.setState({tasks: data})
  }

  appendTask = (newTask) => {
    const clonedTasks = [...this.state.tasks];
    clonedTasks.push(newTask);
    this.setState({tasks: clonedTasks});
  }

  toggleAddTaskModalOpened = () => this.setState({isAddTaskModalOpened: !this.state.isAddTaskModalOpened});

  render() {
    return (
      <>
        {this.state.isAddTaskModalOpened && (
          <AddTaskModal
            toggleAddTaskModalOpened={this.toggleAddTaskModalOpened}
            tasks={this.state.tasks}
            appendTask={this.appendTask}
          />
        )}
        <ItemsList tasks={this.state.tasks} toggleAddTaskModalOpened={this.toggleAddTaskModalOpened} />
      </>
    );
  }
}

export { TodoPage };
