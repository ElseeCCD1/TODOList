import React from 'react';
import './App.css';
import { TodoPage } from "./components/TodoPage";

class App extends React.Component {

  render() {
    return (
      <TodoPage />
    );
  }
}

export default App;
